#include <kipr/wombat.h>

int main()
{
    create_connect();
    
    create_drive_direct(500, 500);
    get_create_lbump();
    get_create_rbump();
    msleep(200000);
    return 0;
}
